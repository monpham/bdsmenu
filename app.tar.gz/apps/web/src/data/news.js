export const newsArticles = [
  {
    id: 'thi-truong-bds-da-nang-2026',
    title: 'Thị Trường Bất Động Sản Đà Nẵng 2026: Xu Hướng Tăng Trưởng Mạnh',
    date: '2026-03-15',
    excerpt: 'Thị trường bất động sản cao cấp tại Đà Nẵng đang có những dấu hiệu tích cực với nhiều dự án mới được triển khai và giá trị gia tăng ổn định.',
    content: 'Theo báo cáo mới nhất từ các chuyên gia bất động sản, thị trường căn hộ cao cấp tại Đà Nẵng đang trải qua giai đoạn tăng trưởng mạnh mẽ. Với vị trí địa lý đắc địa, hạ tầng giao thông phát triển và chính sách thu hút đầu tư, Đà Nẵng đang trở thành điểm đến hấp dẫn cho các nhà đầu tư bất động sản cao cấp.',
    image: 'https://images.unspla518883-ce09059eeffa',
    author: 'Nguyễn Minh Tuấn',
    category: 'Thị Trường'
  },
  {
    id: 'dau-tu-can-ho-cao-cap',
    title: 'Đầu Tư Căn Hộ Cao Cấp: Lựa Chọn Thông Minh Cho Tương Lai',
    date: '2026-03-10',
    excerpt: 'Căn hộ cao cấp không chỉ là nơi an cư mà còn là kênh đầu tư sinh lời bền vững trong dài hạn.',
    content: 'Trong bối cảnh thị trường bất động sản ngày càng phát triển, việc đầu tư vào căn hộ cao cấp tại các vị trí đắc địa như Đà Nẵng đang được nhiều nhà đầu tư quan tâm. Với tỷ suất sinh lời ổn định và khả năng tăng giá trong tương lai, đây là lựa chọn đầu tư thông minh.',
    image: 'https://images.unspla585154526-990dced4db0d',
    author: 'Trần Thị Hương',
    category: 'Đầu Tư'
  },
  {
    id: 'tien-ich-can-ho-hien-dai',
    title: 'Tiện Ích Căn Hộ Hiện Đại: Yếu Tố Quyết Định Giá Trị',
    date: '2026-03-05',
    excerpt: 'Các tiện ích cao cấp như hồ bơi vô cực, phòng gym, khu vui chơi trẻ em đang trở thành tiêu chuẩn mới cho căn hộ cao cấp.',
    content: 'Xu hướng căn hộ cao cấp hiện nay không chỉ chú trọng vào thiết kế nội thất mà còn đầu tư mạnh vào các tiện ích phục vụ cư dân. Hồ bơi vô cực, phòng gym hiện đại, khu vui chơi trẻ em, sân vườn xanh mát là những yếu tố tạo nên giá trị gia tăng cho bất động sản.',
    image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d',
    author: 'Lê Văn Hải',
    category: 'Tiện Ích'
  },
  {
    id: 'phong-thuy-can-ho',
    title: 'Phong Thủy Trong Lựa Chọn Căn Hộ Cao Cấp',
    date: '2026-02-28',
    excerpt: 'Yếu tố phong thủy vẫn đóng vai trò quan trọng trong quyết định mua căn hộ của người Việt Nam.',
    content: 'Khi lựa chọn căn hộ cao cấp, nhiều khách hàng không chỉ quan tâm đến thiết kế và tiện ích mà còn chú ý đến yếu tố phong thủy. Hướng nhà, vị trí, cách bố trí không gian đều ảnh hưởng đến quyết định cuối cùng của người mua.',
    image: 'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea',
    author: 'Phạm Thị Mai',
    category: 'Tư Vấn'
  },
    {
    id: 'phong-thuy-can-ho',
    title: 'Phong Thủy Trong Lựa Chọn Căn Hộ Cao Cấp',
    date: '2026-02-28',
    excerpt: 'Yếu tố phong thủy vẫn đóng vai trò quan trọng trong quyết định mua căn hộ của người Việt Nam.',
    content: 'Khi lựa chọn căn hộ cao cấp, nhiều khách hàng không chỉ quan tâm đến thiết kế và tiện ích mà còn chú ý đến yếu tố phong thủy. Hướng nhà, vị trí, cách bố trí không gian đều ảnh hưởng đến quyết định cuối cùng của người mua.',
    image: 'https://images.566753086-00f18fb6b3ea',
    author: 'Phạm Thị Mai',
    category: 'Tư Vấn'
  },
    {
    id: 'phong-thuy-can-ho',
    title: 'Phong ThủyCăn Hộ Cao Cấp',
    date: '2026-02-28',
    excerpt: 'Yếu tố phong thủy vẫn đóng vai trò quan trọng trong quyết định mua căn hộ của người Việt Nam.',
    content: 'Khi lựa chọn căn hộ cao cấp, nhiều khách hàng không chỉ quan tâm đến thiết kế và tiện ích mà còn chú ý đến yếu tố phong thủy. Hướng nhà, vị trí, cách bố trí không gian đều ảnh hưởng đến quyết định cuối cùng của người mua.',
    image: 'https://images.unsplash.com/3086-00f18fb6b3ea',
    author: 'Phạm Thị Mai',
    category: 'Tư Vấn'
  },
    {
    id: 'phong-thuy-can-ho',
    title: 'Phong Thủy Trong Lựa Chọn Căn Hộ Cao Cấp',
    date: '2026-02-28',
    excerpt: 'Yếu tố phong thủn trọng trong quyết định mua căn hộ của người Việt Nam.',
    content: 'Khi lựa chọn căn hộ cao cấp, n không chỉ quan tâm đến thiết kế và tiện ích mà còn chú ý đến yếu tố phong thủy. Hướng nhà, vị trí, cách bố trí không gian đều ảnh hưởng đến quyết định cuối cùng của người mua.',
    image: 'https://images.unspla566753086-00f18fb6b3ea',
    author: 'Phạm Thị Mai',
    category: 'Tư Vấn'
  }
];