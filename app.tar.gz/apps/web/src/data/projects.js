export const projects = [
  {
    id: 'vinhomes-grand-park',
    name: 'Căn Hộ Cao Cấp Vinhomes Grand Park',
    location: 'Ngũ Hành Sơn, Đà Nẵng',
    price: '8.5 tỷ VND',
    priceNumber: 8500000000,
    shortDescription: 'Căn hộ cao cấp với view biển tuyệt đẹp, thiết kế hiện đại và đầy đủ tiện ích.',
    description: 'Vinhomes Grand Park là dự án căn hộ cao cấp tọa lạc tại vị trí đắc địa ở Ngũ Hành Sơn, Đà Nẵng. Với thiết kế hiện đại, sang trọng và đầy đủ tiện ích 5 sao, dự án mang đến không gian sống đẳng cấp cho cư dân. Căn hộ có view biển tuyệt đẹp, hướng Đông Nam đón gió biển mát mẻ quanh năm.',
    area: '120m²',
    bedrooms: 3,
    bathrooms: 2,
    images: [
      'https://horizons-cdn.hostinger.com/86d8422a-93e6-4f60-849e-fd9aa087ef95/0c15d43f7cc39e6bb2ca86040045a2f0.webp',
      'https://bkbds.bkweb.com.vn/wp-content/uploads/2022/08/Rectangle-4-1.png',
      'https://bkbds.bkweb.com.vn/wp-content/uploads/2022/08/Rectangle-4-1.png',
      'https://bkbds.bkweb.com.vn/wp-content/uploads/2022/08/Rectangle-4-1.png'
    ],
    floorPlans: [
      'https://bkbds.bkweb.com.vn/wp-content/uploads/2022/08/Rectangle-4-1.png',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c'
    ],
    features: [
      'Hồ bơi vô cực',
      'Phòng gym hiện đại',
      'Khu vui chơi trẻ em',
      'Bãi đỗ xe riêng',
      'An ninh 24/7',
      'Sảnh đón sang trọng'
    ],
    paymentTerms: 'Thanh toán 30% khi ký hợp đồng, 40% trong quá trình xây dựng, 30% khi nhận nhà',
    status: 'Đang mở bán',
    completionDate: 'Quý 4/2026'
  },





  {
    id: 'luxury-apartment-my-khe',
    name: 'Dự Án Luxury Apartment Mỹ Khê',
    location: 'Sơn Trà, Đà Nẵng',
    price: '12.3 tỷ VND',
    priceNumber: 12300000000,
    shortDescription: 'Căn hộ penthouse cao cấp ngay bãi biển Mỹ Khê, thiết kế sang trọng bậc nhất.',
    description: 'Luxury Apartment Mỹ Khê là dự án căn hộ cao cấp nằm ngay trung tâm bãi biển Mỹ Khê - một trong những bãi biển đẹp nhất hành tinh. Dự án được thiết kế theo phong cách hiện đại, tối giản với chất liệu cao cấp nhập khẩu từ châu Âu. Mỗi căn hộ đều có ban công rộng với view biển 180 độ.',
    area: '180m²',
    bedrooms: 4,
    bathrooms: 3,
    images: [
      'https://images.unsplda81dd',
      'https://images.unspl1600607687920-4e2a09cf159d',
      'https://images.uns566753086-00f18fb6b3ea',
      'https://images.unsplash00585154526-990dced4db0d'
    ],
    floorPlans: [
      'https://images.unsplo-1503174971373-b1f69850bded',
      'https://images.uto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Bếp cao cấp nhập khẩu',
      'Hệ thống smarthome',
      'Sân vườn riêng',
      'Phòng giặt riêng',
      'View biển 180°',
      'Nội thất cao cấp'
    ],
    paymentTerms: 'Thanh toán 35% khi ký hợp đồng, 35% trong quá trình xây dựng, 30% khi bàn giao',
    status: 'Sắp mở bán',
    completionDate: 'Quý 2/2027'
  },
  {
    id: 'premium-residence-nha-trang',
    name: 'Căn Hộ Cao Cấp Premium Residence',
    location: 'Hải Châu, Đà Nẵng',
    price: '6.8 tỷ VND',
    priceNumber: 6800000000,
    shortDescription: 'Căn hộ cao cấp tại trung tâm thành phố, gần sông Hàn và cầu Rồng.',
    description: 'Premium Residence là dự án căn hộ cao cấp tọa lạc tại vị trí vàng quận Hải Châu, gần sông Hàn và cầu Rồng. Dự án kết hợp hoàn hảo giữa không gian sống hiện đại và tiện ích đô thị đầy đủ. Căn hộ được thiết kế thông minh, tối ưu hóa không gian và ánh sáng tự nhiên.',
    area: '95m²',
    bedrooms: 2,
    bathrooms: 2,
    images: [
      'https://images.unsp9287045-4bb5808fe1f4',
      'https://images.unsphoto-1600607687644-c7171b42498b',
      'https://images.unsplash600566753151-384129cf4e3e',
      'https://images.unsplaso-1600585154363-67eb9e2e2099'
    ],
    floorPlans: [
      'https://images.unsplasto-1503174971373-b1f69850bded',
      'https://images.unsplaoto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Gần trung tâm thương mại',
      'Hệ thống điều hòa trung tâm',
      'Khu BBQ ngoài trời',
      'Phòng đọc sách',
      'Khu thể thao đa năng',
      'Siêu thị mini'
    ],
    paymentTerms: 'Thanh toán 25% khi ký hợp đồng, 45% trong quá trình xây dựng, 30% khi nhận nhà',
    status: 'Đang mở bán',
    completionDate: 'Quý 1/2027'
  },
  {
    id: 'penthouse-da-nang',
    name: 'Dự Án Penthouse Đà Nẵng',
    location: 'Thanh Khê, Đà Nẵng',
    price: '15.2 tỷ VND',
    priceNumber: 15200000000,
    shortDescription: 'Penthouse siêu sang với sân vườn riêng trên tầng thượng, view toàn cảnh thành phố.',
    description: 'Penthouse Đà Nẵng là dự án căn hộ penthouse cao cấp nhất tại Đà Nẵng. Với diện tích lớn và thiết kế độc đáo, mỗi căn penthouse đều có sân vườn riêng trên tầng thượng với view toàn cảnh thành phố và biển. Nội thất được thiết kế bởi các kiến trúc sư hàng đầu, sử dụng vật liệu cao cấp nhất.',
    area: '250m²',
    bedrooms: 5,
    bathrooms: 4,
    images: [
      'https://images.unsplash-1693219514035-ccab087ce6ba',
      'https://images.unspla-1600607687939-ce8a6c25118c',
      'https://images.unsplas-1600566753190-17f0baa2a6c3',
      'https://images.unsplash-1600585154340-be6161a56a0c'
    ],
    floorPlans: [
      'https://images.unsplasoto-1503174971373-b1f69850bded',
      'https://images.unto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Sân vườn riêng 100m²',
      'Hồ bơi riêng',
      'Phòng rượu vang',
      'Thang máy riêng',
      'Bếp đảo cao cấp',
      'Phòng chiếu phim'
    ],
    paymentTerms: 'Thanh toán 40% khi ký hợp đồng, 30% trong quá trình xây dựng, 30% khi bàn giao',
    status: 'Còn 2 căn',
    completionDate: 'Quý 3/2026'
  },
   {
    id: 'penthouse-da-nang',
    name: 'Dự Án Penthouse Đà Nẵng',
    location: 'Thanh Khê, Đà Nẵng',
    price: '15.2 tỷ VND',
    priceNumber: 15200000000,
    shortDescription: 'Penthouse siêu sang với sân vườn riêng trên tầng thượng, view toàn cảnh thành phố.',
    description: 'Penthouse Đà Nẵng là dự án căn hộ penthouse cao cấp nhất tại Đà Nẵng. Với diện tích lớn và thiết kế độc đáo, mỗi căn penthouse đều có sân vườn riêng trên tầng thượng với view toàn cảnh thành phố và biển. Nội thất được thiết kế bởi các kiến trúc sư hàng đầu, sử dụng vật liệu cao cấp nhất.',
    area: '250m²',
    bedrooms: 5,
    bathrooms: 4,
    images: [
      'https://images.unsplash-1693219514035-ccab087ce6ba',
      'https://images.unspla-1600607687939-ce8a6c25118c',
      'https://images.unsplas-1600566753190-17f0baa2a6c3',
      'https://images.unsplash-1600585154340-be6161a56a0c'
    ],
    floorPlans: [
      'https://images.unsplasoto-1503174971373-b1f69850bded',
      'https://images.unto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Sân vườn riêng 100m²',
      'Hồ bơi riêng',
      'Phòng rượu vang',
      'Thang máy riêng',
      'Bếp đảo cao cấp',
      'Phòng chiếu phim'
    ],
    paymentTerms: 'Thanh toán 40% khi ký hợp đồng, 30% trong quá trình xây dựng, 30% khi bàn giao',
    status: 'Còn 2 căn',
    completionDate: 'Quý 3/2026'
  },
  {
    id: 'penthouse-da-nang',
    name: 'Dự Án Penthouse Đà Nẵng',
    location: 'Thanh Khê, Đà Nẵng',
    price: '15.2 tỷ VND',
    priceNumber: 15200000000,
    shortDescription: 'Penthouse siêu sang với sân vườn riêng trên tầng thượng, view toàn cảnh thành phố.',
    description: 'Penthouse Đà Nẵng là dự án căn hộ penthouse cao cấp nhất tại Đà Nẵng. Với diện tích lớn và thiết kế độc đáo, mỗi căn penthouse đều có sân vườn riêng trên tầng thượng với view toàn cảnh thành phố và biển. Nội thất được thiết kế bởi các kiến trúc sư hàng đầu, sử dụng vật liệu cao cấp nhất.',
    area: '250m²',
    bedrooms: 5,
    bathrooms: 4,
    images: [
      'https://images.unsplash-1693219514035-ccab087ce6ba',
      'https://images.unspla-1600607687939-ce8a6c25118c',
      'https://images.unsplas-1600566753190-17f0baa2a6c3',
      'https://images.unsplash-1600585154340-be6161a56a0c'
    ],
    floorPlans: [
      'https://images.unsplasoto-1503174971373-b1f69850bded',
      'https://images.unto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Sân vườn riêng 100m²',
      'Hồ bơi riêng',
      'Phòng rượu vang',
      'Thang máy riêng',
      'Bếp đảo cao cấp',
      'Phòng chiếu phim'
    ],
    paymentTerms: 'Thanh toán 40% khi ký hợp đồng, 30% trong quá trình xây dựng, 30% khi bàn giao',
    status: 'Còn 2 căn',
    completionDate: 'Quý 3/2026'
  },
  {
    id: 'penthouse-da-nang',
    name: 'Dự Án Penthouse Đà Nẵng',
    location: 'Thanh Khê, Đà Nẵng',
    price: '15.2 tỷ VND',
    priceNumber: 15200000000,
    shortDescription: 'Penthouse siêu sang với sân vườn riêng trên tầng thượng, view toàn cảnh thành phố.',
    description: 'Penthouse Đà Nẵng là dự án căn hộ penthouse cao cấp nhất tại Đà Nẵng. Với diện tích lớn và thiết kế độc đáo, mỗi căn penthouse đều có sân vườn riêng trên tầng thượng với view toàn cảnh thành phố và biển. Nội thất được thiết kế bởi các kiến trúc sư hàng đầu, sử dụng vật liệu cao cấp nhất.',
    area: '250m²',
    bedrooms: 5,
    bathrooms: 4,
    images: [
      'https://images.unsplash-1693219514035-ccab087ce6ba',
      'https://images.unspla-1600607687939-ce8a6c25118c',
      'https://images.unsplas-1600566753190-17f0baa2a6c3',
      'https://images.unsplash-1600585154340-be6161a56a0c'
    ],
    floorPlans: [
      'https://images.unsplasoto-1503174971373-b1f69850bded',
      'https://images.unto-1600585154340-be6161a56a0c'
    ],
    features: [
      'Sân vườn riêng 100m²',
      'Hồ bơi riêng',
      'Phòng rượu vang',
      'Thang máy riêng',
      'Bếp đảo cao cấp',
      'Phòng chiếu phim'
    ],
    paymentTerms: 'Thanh toán 40% khi ký hợp đồng, 30% trong quá trình xây dựng, 30% khi bàn giao',
    status: 'Còn 2 căn',
    completionDate: 'Quý 3/2026'
  }
  
];