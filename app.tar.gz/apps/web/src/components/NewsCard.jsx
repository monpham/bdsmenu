import React from 'react';
import { Calendar, User } from 'lucide-react';
import { motion } from 'framer-motion';

function NewsCard({ article, index = 0 }) {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 border border-gray-100"
    >
      {/* Image */}
      <div className="relative h-56 overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title}
          className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4 bg-[#D4AF37] text-white px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide" style={{fontFamily: 'Open Sans, sans-serif'}}>
          {article.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="text-xl font-bold text-[#0B1F3B] mb-3 hover:text-[#D4AF37] transition-colors duration-200 leading-snug" style={{fontFamily: 'Montserrat, sans-serif', letterSpacing: '-0.01em'}}>
          {article.title}
        </h3>

        <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4 text-[#D4AF37]" />
            <span style={{fontFamily: 'Open Sans, sans-serif'}}>{formatDate(article.date)}</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="h-4 w-4 text-[#D4AF37]" />
            <span style={{fontFamily: 'Open Sans, sans-serif'}}>{article.author}</span>
          </div>
        </div>

        <p className="text-sm text-gray-600 leading-relaxed line-clamp-6" style={{fontFamily: 'Open Sans, sans-serif'}}>
          {article.excerpt}
        </p>
      </div>
    </motion.article>
  );
}

export default NewsCard;